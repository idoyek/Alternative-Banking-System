package client;

import schema.generated.AbsDescriptor;
import xml.Xml;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface DatabaseInterface {

    public Map<String, Loan> getLoansMap();

    public void addLoanToMap(Loan loan);

    public Map<String, Client> getClientsMap();

    public void addClientToMap(Client client);

    public List<String> getCategoriesList();

    public void addCategoryToList(String category);

    public Yaz getYaz();

    public void setYaz(Yaz yaz);

    public Xml getXml();

    public void setXml(Xml xml);

    public void addMoneyToAccount(int num, String name);

    public void withdrawMoney(int num, String name);

    public boolean checkLoanSuitability(String investorName,Loan loan, List<String> categoriesList, int minInterestPerYaz, int minYazTime, int maxOpenLoans);

    //public Loan getLoanById(String loanId);

    public String getLoanerNameById(String loanId);

    public String getLoanerNameByIdHelper(String loanId);

    public void assignInvestmentByMinimalLoan(String investorName, int investmentAmount, List<Loan> investorLoansChoices,int maxOwnershipPercentage);

    public void turnLoanToActive(String investorName, int moneyToAdd, Loan loan);

    public Loan findMinimalLoan(List<Loan> investorLoansChoices);

    public int divideEqually(String investorName, int divide,int investmentAmount, List<Loan> loansList, int maxOwnershipPercentage);

    //public void copyClassesFromXml(String pathName);

    public void clearAll();

    public void addCategories(AbsDescriptor descriptor);

    //public void checkIfCopySucceeded(AbsDescriptor descriptor);

    //public void checkForDuplicateClients(AbsDescriptor descriptor);

    public void checkCategories();

    public void checkClients();

    //public void checkYaz();

    public void loansRepayment(Loan loan);

    public void loanRepaymentInRisk(Loan loan, int amountToPay);

    public void closeEntireLoan(Loan loan);

    public void riskMode(Loan loan);

    public void addNotifications();

    //public String getFileType(String fullName);

    public boolean negativeInputCheck(int amountToInvest);
    public boolean moreThanMaximalAmountCheck(String investorName,int amount);
    public boolean checkAmountToInvestInput(String investorName,int amountToInvest);

    //public Map<Loan,String> getLoansForSaleMap();

    //public void addToLoansForSaleMap(Loan loanForSale, String sellerName);

//    public boolean checkCategories();
//
//    public boolean checkClients();
//
//    public boolean checkYaz();
//
//    public boolean checkForDuplicateClients(AbsDescriptor descriptor);

}