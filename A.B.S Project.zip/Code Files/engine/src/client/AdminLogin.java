package client;

import java.util.ArrayList;
import java.util.List;

public class AdminLogin {
    private boolean isAdminLogin;

    public boolean getIsAdminLogin() {
        return isAdminLogin;
    }

    public void setIsAdminLogin(boolean adminLogin) {
        isAdminLogin = adminLogin;
    }
}
