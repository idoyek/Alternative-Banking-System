package tableViews;

import client.Client;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import body.BodyController;

import java.net.URL;
import java.util.ResourceBundle;

public class CustomersInformationController implements Initializable {
    private BodyController bodyController;

    @FXML
    private TableView<Client> tableViewWindow;

    @FXML
    private TableColumn<Client, String> nameColumn;

    @FXML
    private TableColumn<Client, Integer> totalBalanceColumn;


    public void setBodyController(BodyController adminBodyController) {
        this.bodyController = adminBodyController;
    }
    public TableView<Client> getTableView(){
        return tableViewWindow;
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        totalBalanceColumn.setCellValueFactory(new PropertyValueFactory<>("totalMoney"));
    }

}
